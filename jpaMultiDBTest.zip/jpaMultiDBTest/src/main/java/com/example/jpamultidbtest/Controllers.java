package com.example.jpamultidbtest;

import com.example.jpamultidbtest.slave.MessageRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class Controllers {

    private final MessageRepo messageRepo;

    @GetMapping("/ttes")
    @ResponseBody
    public String testt() {
        messageRepo.insert();
        return "";
    }
}
