package com.example.jpamultidbtest.slave;

import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

@Repository
@RequiredArgsConstructor
public class MessageRepo {

    private final JdbcTemplate  jdbcTemplate;

    public void insert() {
        String sql = "INSERT INTO messageque(msg, types) VALUES(?, ?)";
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(new PreparedStatementCreator() {
            @Override
            public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
                PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                ps.setString(1, "test write message");
                ps.setString(2, "START");
                return ps;
            }
        }, keyHolder);

        int generatedId = keyHolder.getKey().intValue();
        System.out.println("### DY ### " + generatedId);
    }
}