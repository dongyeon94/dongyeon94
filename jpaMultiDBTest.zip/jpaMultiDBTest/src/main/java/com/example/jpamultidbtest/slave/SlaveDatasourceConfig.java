package com.example.jpamultidbtest.slave;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;

@Configuration
public class SlaveDatasourceConfig {

    @Value("${second.datasource.driver-class-name}")
    private String dbDriverClass;

    @Value("${second.datasource.url}")
    private String dburl;

    @Value("${second.datasource.username}")
    private String username;

    @Value("${second.datasource.password}")
    private String password;

    private Environment environment;
//
    @Bean
    public DataSource seconddataSource() {
        DriverManagerDataSource driver = new DriverManagerDataSource();
        driver.setDriverClassName(dbDriverClass);
        driver.setUrl(dburl);
        driver.setUsername(username);
        driver.setPassword(password);
//        driver.setDriverClassName(environment.getProperty("spring.second.datasource.driver-class-name"));
//        driver.setUrl(environment.getProperty("spring.second.datasource.url"));
//        driver.setUsername(environment.getProperty("spring.second.datasource.username"));
//        driver.setPassword(environment.getProperty("spring.second.datasource.password"));
        return driver;
    }
//
    @Bean
    public JdbcTemplate jdbcTemplate(@Qualifier("seconddataSource") DataSource ds) {
        return new JdbcTemplate(ds);
    }

//    @SuppressWarnings("rawtypes")
//    @Bean(name = "secondSource")
//    public DataSource  dataSource() {
//        DataSourceBuilder dataSourceBuilder = DataSourceBuilder.create();
//        dataSourceBuilder.driverClassName(dbDriverClass);
//        dataSourceBuilder.url(dburl);
//        dataSourceBuilder.username(username);
//        dataSourceBuilder.password(password);
//        return dataSourceBuilder.build();
//    }

//    @Bean
//    public SqlSessionFactory sqlSessionFactory(DataSource dataSource) throws Exception {
//        final SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
//        sqlSessionFactoryBean.setDataSource(dataSource());
//        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
//        sqlSessionFactoryBean.setMapperLocations(resolver.getResource("classpath:/mapper/**/*.xml"));
//        return sqlSessionFactoryBean.getObject();
//    }
//
//    @Bean
//    public SqlSessionTemplate sqlSessionTemplate(SqlSessionFactory sqlSessionFactory) throws Exception {
//        final SqlSessionTemplate sqlSessionTemplate = new SqlSessionTemplate(sqlSessionFactory);
//        return sqlSessionTemplate;
//    }
//
//    @Bean
//    public DataSourceTransactionManager dataSourceTransactionManager() {
//        DataSourceTransactionManager manager = new DataSourceTransactionManager(dataSource());
//        return manager;
//    }
}