package com.example.jpamultidbtest.master.board;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "boards")
@Getter @Setter
public class Boards {

    @Id @GeneratedValue
    private Long ids;

    private String title;
    @Lob
    private String content;
}
