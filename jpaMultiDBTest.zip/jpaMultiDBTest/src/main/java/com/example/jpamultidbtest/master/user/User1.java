package com.example.jpamultidbtest.master.user;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "memembers")
@Getter @Setter
public class User1 {

    @Id @GeneratedValue
    private Long ids;

    private String email;
    private String password;
}
