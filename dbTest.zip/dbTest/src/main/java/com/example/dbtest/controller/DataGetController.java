package com.example.dbtest.controller;

import com.example.dbtest.domain.MessageQueue;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequiredArgsConstructor
public class DataGetController {

    private final MessageRepo messageRepo;

    @PostMapping("/tttt")
    public String tt(){
        LocalDate today = LocalDate.now();
        LocalDate last = today.minusDays(30);
        System.out.println("go");
        System.out.println("go");
        List li = messageRepo.findByDateBetween(last, today);
        System.out.println(li.toString());
        String msg = "";
        for(Object ob : li){
            MessageQueue mes = (MessageQueue) ob;
            msg += "[ " + mes.getId() + " ] ";
            msg += "[ " + mes.getMessagesText() + " ] ";
            msg += "[ " + mes.getDate() + " ] ";


            msg += "[ " + mes.getMessageType() + " ] ";
            msg += "\n\n";

        }
        return msg;
    }
}
