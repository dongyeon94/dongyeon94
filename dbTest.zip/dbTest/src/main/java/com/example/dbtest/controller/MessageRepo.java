package com.example.dbtest.controller;

import com.example.dbtest.domain.MessageQueue;
import org.springframework.data.jpa.repository.JpaRepository;

import javax.transaction.Transactional;
import java.time.LocalDate;
import java.util.List;

@Transactional
public interface MessageRepo extends JpaRepository<MessageQueue, Long> {

    List<MessageQueue> findByDateBetween(LocalDate todays, LocalDate plusDays);
}
