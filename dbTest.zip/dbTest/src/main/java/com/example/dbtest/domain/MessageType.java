package com.example.dbtest.domain;

public enum MessageType {
    ABSENSCE, START, END, WEB
}
