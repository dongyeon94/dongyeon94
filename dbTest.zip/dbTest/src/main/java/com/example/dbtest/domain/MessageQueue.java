package com.example.dbtest.domain;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "message_queue")
@Getter
public class MessageQueue {

    @Id
    private long id;

    @Enumerated(EnumType.STRING)
    private MessageType messageType;

    @Lob
    @Column(columnDefinition = "text")
    private String messagesText;

    private LocalDate date;
}